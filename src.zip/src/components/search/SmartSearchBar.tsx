import { matchesBusinessSearch } from '../../utils/arabicSearch';
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Search, MapPin, Compass, X, History, Sparkles } from 'lucide-react';
import { Business } from '../../types';
import { EGYPT_GOVERNORATES } from '../../data/mockData';

export interface SmartSearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedGov: string;
  onGovChange: (gov: string) => void;
  selectedCity?: string;
  onCityChange?: (city: string) => void;
  userCoords: { lat: number; lng: number } | null;
  isLocatingUser: boolean;
  onRequestLocation: () => void;
  businesses: Business[];
  onSelectBusiness?: (business: Business) => void;
  onSearchSubmit?: () => void;
  compact?: boolean;
}

export const SmartSearchBar: React.FC<SmartSearchBarProps> = ({
  searchQuery,
  onSearchChange,
  selectedGov,
  onGovChange,
  selectedCity,
  onCityChange = () => {},
  userCoords,
  isLocatingUser,
  onRequestLocation,
  businesses,
  onSelectBusiness,
  onSearchSubmit,
  compact = false,
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  // Load Recent Searches from LocalStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('dalelak_recent_searches');
      if (saved) {
        const parsed: unknown = JSON.parse(saved);
        if (Array.isArray(parsed)) setRecentSearches(parsed.filter((v): v is string => typeof v === 'string').slice(0, 5));
      }
    } catch {}
  }, []);

  const addRecentSearch = (term: string) => {
    if (!term || !term.trim()) return;
    const clean = term.trim();
    try {
      const updated = [clean, ...recentSearches.filter((t) => t !== clean)].slice(0, 5);
      setRecentSearches(updated);
      localStorage.setItem('dalelak_recent_searches', JSON.stringify(updated));
    } catch {}
  };

  const handleClearRecent = () => {
    setRecentSearches([]);
    try {
      localStorage.removeItem('dalelak_recent_searches');
    } catch {}
  };

  // Instant Suggestions (Filtered Businesses)
  const suggestions = useMemo(() => {
    if (!searchQuery || searchQuery.trim().length < 2) return [];
    const q = searchQuery.toLowerCase().trim();
    return businesses
      .filter((b) => matchesBusinessSearch(b, q))
      .slice(0, 5);
  }, [searchQuery, businesses]);

  const handleSubmit = (e?: React.FormEvent, term = searchQuery) => {
    if (e) e.preventDefault();
    if (term.trim()) {
      addRecentSearch(term.trim());
    }
    setIsFocused(false);
    if (onSearchSubmit) onSearchSubmit();
  };

  return (
    <div className={`relative w-full ${compact ? 'max-w-3xl' : 'max-w-4xl'} mx-auto`} ref={containerRef} onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setIsFocused(false); }}>
      <form
        onSubmit={handleSubmit}
        className="bg-[var(--bg-card)] border-2 border-amber-500/30 hover:border-amber-500/60 focus-within:border-amber-500 rounded-2xl p-1.5 sm:p-2 shadow-lg shadow-amber-500/5 backdrop-blur-md transition-all flex flex-col md:flex-row items-stretch md:items-center gap-1.5"
      >
        {/* Field 1: What? (ماذا تبحث عنه؟) + Action Button on Mobile */}
        <div className="flex items-center gap-1.5 flex-1 min-w-0">
          <div className="relative flex-1 flex items-center min-w-0">
            <Search className="w-4 h-4 text-amber-500 absolute right-3 pointer-events-none shrink-0" />
            <input
              type="search"
              enterKeyHint="search"
              aria-label="ابحث عن نشاط أو خدمة"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onKeyDown={(e) => { if (e.key === 'Escape') setIsFocused(false); }}
              placeholder="ابحث عن مطعم، طبيب، صيدلية، خدمة..."
              className="directory-search-input w-full min-h-11 bg-transparent pr-9 pl-11 py-2 text-base sm:text-sm font-bold text-[var(--text-primary)] placeholder:text-[var(--text-muted)] focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute left-0 w-11 h-11 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
                title="مسح"
                aria-label="مسح البحث"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Submit Button on Mobile (visible only on small screens for ultra-quick tap) */}
          <button
            type="submit"
            className="md:hidden min-h-11 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs px-3.5 py-2 rounded-xl shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1 shrink-0"
            aria-label="بحث"
          >
            <Search className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>بحث</span>
          </button>
        </div>

        <div className="hidden md:block w-px h-7 bg-slate-200 shrink-0" />

        {/* Field 2: Where? (المحافظة / النطاق الجغرافي) */}
        <div className="min-h-11 flex items-center gap-1.5 bg-slate-50 md:bg-transparent rounded-xl px-2.5 py-1 md:py-0 md:px-1 border border-slate-200/70 md:border-none min-w-0 md:min-w-[220px]">
          <MapPin className="w-3.5 h-3.5 text-amber-600 md:text-slate-400 shrink-0" />
          <select
            value={selectedCity && selectedCity !== 'all' ? selectedCity : selectedGov}
            onChange={(e) => {
              const val = e.target.value;
              if (val === 'all') {
                onGovChange('all');
                onCityChange('all');
              } else if (val === 'حدائق الأهرام') {
                onGovChange('الجيزة');
                onCityChange('حدائق الأهرام');
              } else if (
                val === 'مدينة 6 أكتوبر' ||
                val === 'مدينة الشيخ زايد' ||
                val === 'الهرم' ||
                val === 'فيصل'
              ) {
                onGovChange('الجيزة');
                onCityChange(val);
              } else {
                onGovChange(val);
                onCityChange('all');
              }
            }}
            className="flex-1 min-w-0 min-h-11 bg-transparent py-1 text-base sm:text-xs font-bold text-[var(--text-primary)] focus:outline-none cursor-pointer truncate"
            aria-label="اختر النطاق الجغرافي"
            style={{ colorScheme: 'light' }}
          >
            <option value="حدائق الأهرام" className="bg-white text-slate-900 font-bold">حدائق الأهرام (الافتراضي)</option>
            <option value="all" className="bg-white text-slate-900 font-bold">كل محافظات مصر</option>
            <option value="الجيزة" className="bg-white text-slate-900 font-bold">محافظة الجيزة (الكل)</option>
            <option value="مدينة 6 أكتوبر" className="bg-white text-slate-900 font-bold">مدينة 6 أكتوبر</option>
            <option value="مدينة الشيخ زايد" className="bg-white text-slate-900 font-bold">مدينة الشيخ زايد</option>
            <option value="الهرم" className="bg-white text-slate-900 font-bold">شارع الهرم</option>
            <option value="فيصل" className="bg-white text-slate-900 font-bold">شارع فيصل</option>
            <option value="القاهرة" className="bg-white text-slate-900 font-bold">محافظة القاهرة</option>
            <option value="الإسكندرية" className="bg-white text-slate-900 font-bold">محافظة الإسكندرية</option>
            {EGYPT_GOVERNORATES.filter((g) => g !== 'الجيزة' && g !== 'القاهرة' && g !== 'الإسكندرية').map((gov) => (
              <option key={gov} value={gov} className="bg-white text-slate-900 font-bold">
                {gov}
              </option>
            ))}
          </select>

          {/* Near Me GPS Proximity Button */}
          <button
            type="button"
            onClick={onRequestLocation}
            disabled={isLocatingUser}
            className={`min-h-11 px-2.5 py-1 rounded-lg text-[10.5px] font-black flex items-center gap-1 transition-all cursor-pointer shrink-0 ${
              userCoords
                ? 'bg-emerald-500/15 text-emerald-700 border border-emerald-500/30'
                : 'bg-white hover:bg-amber-50 text-slate-700 hover:text-amber-800 border border-slate-200'
            }`}
            title="تحديد مكاني الحالي عبر GPS"
            aria-label="تحديد مكاني الحالي"
          >
            <Compass className={`w-3 h-3 ${isLocatingUser ? 'animate-spin text-amber-600' : userCoords ? 'text-emerald-600' : 'text-slate-500'}`} />
            <span>{userCoords ? 'موقعي نشط' : 'قربي'}</span>
          </button>
        </div>

        {/* Submit / Action Button (Visible on md and up) */}
        <button
          type="submit"
          className="hidden md:flex bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-sm transition-all cursor-pointer items-center justify-center gap-1.5 shrink-0"
        >
          <Search className="w-4 h-4" />
          <span>بحث</span>
        </button>
      </form>

      {/* Autocomplete & Suggestions Dropdown */}
      {isFocused && (
        <div className="absolute top-full right-0 left-0 mt-2 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-2xl shadow-2xl z-50 overflow-hidden text-xs animate-fade-in">
          <div className="p-3 space-y-3 max-h-[min(18rem,40dvh)] overflow-y-auto overscroll-contain text-right">
            {/* Matching Businesses */}
            {suggestions.length > 0 && (
              <div className="space-y-1">
                <span className="text-[10.5px] font-black text-[var(--text-muted)] block px-2">
                  أنشطة مقترحة
                </span>
                {suggestions.map((biz) => (
                  <button
                    key={biz.id}
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => {
                      if (onSelectBusiness) onSelectBusiness(biz);
                      else {
                        onSearchChange(biz.nameAr);
                        handleSubmit(undefined, biz.nameAr);
                      }
                    }}
                    className="w-full text-right p-2 rounded-xl hover:bg-slate-100 flex items-center justify-between gap-2 transition-colors cursor-pointer"
                  >
                    <div className="min-w-0">
                      <p className="font-black text-[var(--text-primary)] truncate">{biz.nameAr}</p>
                      <p className="text-[10px] text-[var(--text-muted)] truncate">{biz.category} • {biz.governorate}</p>
                    </div>
                    <span className="text-[10px] bg-amber-500/15 text-amber-700 px-2 py-0.5 rounded-md shrink-0 font-bold">
                      عرض
                    </span>
                  </button>
                ))}
              </div>
            )}

            {/* Recent Searches */}
            {!searchQuery && recentSearches.length > 0 && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between px-2">
                  <span className="text-[10.5px] font-black text-[var(--text-muted)] flex items-center gap-1">
                    <History className="w-3 h-3 text-slate-400" />
                    <span>عمليات البحث الأخيرة</span>
                  </span>
                  <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={handleClearRecent}
                    className="text-[10px] text-rose-500 hover:text-rose-600 font-bold cursor-pointer"
                  >
                    مسح السجل
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5 px-2">
                  {recentSearches.map((term, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        onSearchChange(term);
                        handleSubmit(undefined, term);
                      }}
                      className="px-3 py-1 rounded-lg bg-slate-100 hover:bg-amber-50 text-slate-700 hover:text-amber-800 text-[11px] font-bold cursor-pointer transition-colors"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Popular quick ideas when empty */}
            {!searchQuery && recentSearches.length === 0 && (
              <div className="space-y-1.5 px-2 py-1">
                <span className="text-[10.5px] font-black text-[var(--text-muted)] flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  <span>عمليات بحث شائعة في مصر</span>
                </span>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {['مطاعم بيتزا', 'صيدلية 24 ساعة', 'عيادة أسنان', 'صيانة سيارات', 'محل ملابس', 'جيم ولياقة'].map(
                    (term, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          onSearchChange(term);
                          handleSubmit(undefined, term);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-amber-50 text-slate-700 hover:text-amber-800 text-[11px] font-bold cursor-pointer transition-colors"
                      >
                        {term}
                      </button>
                    )
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
